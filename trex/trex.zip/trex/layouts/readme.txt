trex_tpu         //CPU: 16 Bit ALU/register module
trex_tcu         //CPU: control unit
trex_main_flg    //CPU: main PCB. Status register, bus interface etc.

trex_mem         //memory PCB.
trex_sram        //SRAM module
trex_eeprom      //EEPROM module (DIP).  untested.
trex_eeprom_plcc //EEPROM module (PLCC). untested.

trex_io          //I/O PCB.                    untested.
ttmr             //timer module.
tlpt             //LPT module.
tkp              //Keyboard interface module.
tuart            //UART module.

trex_ecf         //Ethernet/Compact_Flash PCB. untested.

trex_term        //bus termination, untested.

