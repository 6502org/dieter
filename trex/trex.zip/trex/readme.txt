Dieter 09/2008: Latest TREX CPU status.

During the past 4 months, my job did leave me no time at all to work
on my hobby project. Now that I have vacation, I tried to continue this
project five times, and five times my brain stalled.

Feels like a serious sign of "burnout", so I decided to stop the project,
to make some backups, and to put all the project files into the internet.

Known bugs:

1) sort of a "metastability" problem when trying to trigger a single step
   instruction through the TTAP interface.
   The effect varies when changing TREX CPU clock or the time delay
   in the TTAP software.

2) TTAP software is still experimental and unfinished, please don't laugh
   about the ugly code.

3) interrupt mechanism is untested, and it probably won't work.

4) CPU bus arbitration (for plugging multible CPUs into one backplane)
   is untested, and it probably won't work.

5) the PCB for active bus termination was never built, don't know if this
   stuff will work.

To my software guru:
Thanks for the nice discussions about CPU architecture, about
hardware and software in general, and about god and the world.
Without you, this project wouldn't have started at all.
I feel very sorry for putting everything on a permanent hold.

For those who might want to continue/rebuild this project:
please consider, that the PCBs and components will cost
plenty of money, and that all the schematics and layouts
might be partially untested/unfinished.

That's all for now, sorry to spoil your expectations.

Regards,
Dieter.
