Dieter 05/2008:

mt15.c //MT15 simulator
spi.c  //program to load *.bin into MT15 hardware

mt15_fin //the latest version of the MT15 test software

The *.bat files and mt15h.inc are for generating mt15.inc,
which contains the definitions for the MT15 instruction set
(did use the AS macro assembler in 68k mode).
m_op.bat will start this process.

To run the simulator,
start mt15.exe,
type l mt15_fin.bin, then g 0
You should see the results from running mt15 machine code
on the right side of the screen, basically mt15_fin is a
simple monitor program.
You could leave the emulator mode by pressing F12,
and end mt15.exe with typing q, then pressing ENTER.

