PDF versions of the schematics were contributed 
by Marcin Chwedczuk and originally posted here:

https://github.com/marcin-chwedczuk/dieter-drc2-extras
https://github.com/6502org/dieter/issues/1

