Dieter 08/2003: meine selbstgebaute CPU.
Belegt zwei Leiterplatten. 
Hat in etwa die Geschwindigkeit eines 1 MHz 6502, ein paar 65C816-Befehle,
kann 16MB adressieren. 

Dieter 08/2003: My self_built CPU.
Requires two PCBs.
Has about the speed of a 1MHz 6502, some 65C816 OpCodes, can address 16 MB.


Achtung:   PHI2 nichtperiodisch, funktioniert nicht mit 6502_Peripherie.
Attention: PHI2 is non_periodic, will not work with 6502_periphals.

Achtung:   Speicher sollte OpCode mindestens 200 ns vor Ende des laufenden
           Maschinenzyklus (ALU_Takt, 3 MHz) bereitstellen.
Attention: Memory should have OpCode ready at least 200 ns before the running
           machine_cycle (ALU_clock, 3 MHz) is completed.


WARNUNG:   Hardware_Inkompatibilitaet: CMP_Befehl weicht moeglicherweise im
           Dezimal_Modus vom Original_6502 ab: er arbeitet dezimal.
WARNING:   Harware_incompatibility: CMP_Command will probably not work like
           in the original 6502 in DecimalMode: it may work decimal.

WARNUNG:   m1alu.c unterstuezt keinen Dezimal_Modus.
           Steckt den 3-poligen Jumper oberhalb von IC18 nach VCC,
           fuer 27C512.
WARNING:   m1alu.c supports no DecimalMode.
           Place the 3-pin jumper above IC18 to VCC, for using 27C512.

;----------------------------------------------------------------------------

      Eigentlich lassen sich 32_polige EPROMs als ALU bestuecken...
      ist aber nur eine Option, die vom Microcode nicht unterstuetzt wird.

      Nur nicht verwirren lassen.
      Alles hier hat seinen tieferen Sinn... und welchen, das wuesste ich
      manchmal auch gerne.


      It is possible to plug in 31_pin EPROMs as ALU...
      but that is only an option, not supported by microcode.

      Don't get confused, everything in here has it's deeper sense/purpose...
      if I only whoud know it.

;----------------------------------------------------------------------------

m1code.asm: M01,M02 Microcode                M01,M02 Microcode (SourceCode)
m1alu.c   : M01,M02 ALU, kein DezimalModus.  M01,M02 ALU, no DecimalMode

m1make.bat: erzeugt Microcode-Binaerdateien. generates Microcode_binaries

m1cgen.c:   erzeugt ALU-Binaerdateien.       generates ALU_binaries

m1al.bin:   ALU Bit 0..3
m1ah.bin:   ALU Bit 4..7

m1l.bin:    Microcode  0.. 7
m1m.bin:    Microcode  8..15
m1h.bin:    Microcode 16..23
m1x.bin:    Microcode 24..31

;----------------------------------------------------------------------------

M01 war der Vorlaeufer von M02.
M02 ist ein Ueberarbeiteter Aufbau, im Wesentlichen wurde das Timing
veraendert, und ein zusaetzliches Microcode-EPROM steuert A16..23.
Die Binaerdateien fuer die ALU (M1AL.bin,M1AH.bin) und die unteren 24 Bits
des Microcode sind fuer M01 und M02 soweit identisch.

M01 was the predecessor of M02.
M02 is a worked_over version, on the whole the timing had been modified,
and an additional Microcode_EPROM controls A16..23
The binaries for the ALU (M1AL.bin, M1AH.bin) and the lower 24 Bits
of the Microcode are identical for M01 and M02.


;----------------------------------------------------------------------------
//sorry for my bad English.
;----------------------------------------------------------------------------
